# 新旧朗2 旧版ファイル削除ツール

旧 Inno Setup 版で作成されたフォルダーを、管理者権限で削除するための単発ツールです。
新旧朗2をインストールしたり、AviUtl2 カタログの定義を変更したりしません。

## ユーザーの操作

1. AviUtl2 と新旧朗2を終了する。
2. カタログ版をインストール済みの場合は、AviUtl2 カタログからアンインストールする。
3. `Syncroh2_LegacyCleanup.exe` を実行し、Windows の管理者権限の確認に応じる。
4. 表示される削除対象を確認して「削除」を押す。
5. 削除完了後、必要に応じて AviUtl2 カタログから新旧朗2をインストールする。

削除対象は `%ProgramData%\aviutl2\Plugin\Syncroh2` と
`%ProgramData%\aviutl2\Script\Syncroh2` の2フォルダーと、その中身すべてです。
カタログ版をインストールしたまま実行すると、カタログの管理するファイルも削除されます。

このツールは旧 Inno Setup のアンインストール登録や、ほかの場所にある Desktop 本体を削除しません。

## 作成

Inno Setup 6 をインストールし、`BuildLegacyCleanup.bat` を実行します。
生成物は `Output/Syncroh2_LegacyCleanup.exe` です。
